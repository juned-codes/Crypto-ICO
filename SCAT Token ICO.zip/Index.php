<!-- Save as index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Multi-Send Crypto</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f5f6fa;
      padding: 30px;
    }
    h2 {
      text-align: center;
    }
    .container {
      max-width: 700px;
      margin: auto;
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    }
    input, textarea, select, button {
      width: 100%;
      padding: 12px;
      margin-top: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 16px;
    }
    button {
      background: #2ecc71;
      color: white;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s;
    }
    button:hover {
      background: #27ae60;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Multi-Send ERC-20 Tokens (Mainnet Only)</h2>
  <form id="sendForm">
    <label>Private Key (without 0x)</label>
    <input type="text" id="privateKey" required>

    <label>Token Contract Address</label>
    <input type="text" id="tokenAddress" placeholder="e.g. 0x..." required>

    <label>Amount to Send (per address)</label>
    <input type="text" id="amount" placeholder="e.g. 0.5" required>

    <label>Recipient Addresses (one per line)</label>
    <textarea id="recipients" rows="6" placeholder="0xABC...\n0xDEF..." required></textarea>

    <label>Network</label>
    <select id="network">
      <option value="eth">Ethereum Mainnet</option>
      <option value="bsc">BNB Chain</option>
      <option value="polygon">Polygon</option>
      <option value="arbitrum">Arbitrum</option>
      <option value="optimism">Optimism</option>
      <option value="base">Base</option>
    </select>

    <button type="submit">Send Tokens</button>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/web3@1.10.0/dist/web3.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
document.getElementById('sendForm').addEventListener('submit', async function(e) {
  e.preventDefault();

  const privateKey = document.getElementById('privateKey').value.trim();
  const tokenAddress = document.getElementById('tokenAddress').value.trim();
  const amount = document.getElementById('amount').value.trim();
  const recipients = document.getElementById('recipients').value.trim().split('\n').map(a => a.trim()).filter(a => a);
  const network = document.getElementById('network').value;

  if (!privateKey || !tokenAddress || !amount || recipients.length === 0) {
    Swal.fire('Error', 'Please fill in all fields.', 'error');
    return;
  }

  const networks = {
    eth: {rpc: 'https://mainnet.infura.io/v3/0ceb7ca53d0d4a579364c8dfe2f2be57', chainId: 1},
    bsc: {rpc: 'https://bsc-dataseed.binance.org', chainId: 56},
    polygon: {rpc: 'https://polygon-rpc.com', chainId: 137},
    arbitrum: {rpc: 'https://arb1.arbitrum.io/rpc', chainId: 42161},
    optimism: {rpc: 'https://mainnet.optimism.io', chainId: 10},
    base: {rpc: 'https://mainnet.base.org', chainId: 8453}
  };

  const web3 = new Web3(new Web3.providers.HttpProvider(networks[network].rpc));
  const account = web3.eth.accounts.privateKeyToAccount('0x' + privateKey);
  web3.eth.accounts.wallet.add(account);

  const tokenAbi = [
    {"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],
     "name":"transfer","outputs":[{"name":"","type":"bool"}],"type":"function"}
  ];
  const token = new web3.eth.Contract(tokenAbi, tokenAddress);

  const amountToSend = web3.utils.toWei(amount, 'ether');
  let nonce = await web3.eth.getTransactionCount(account.address, 'pending');
  let success = 0, failed = 0;

  Swal.fire({
    title: 'Sending Tokens...',
    html: `Please wait while we send tokens to <b>${recipients.length}</b> addresses.`,
    allowOutsideClick: false,
    didOpen: () => Swal.showLoading()
  });

  for (const recipient of recipients) {
    try {
      const tx = {
        from: account.address,
        to: tokenAddress,
        gas: 100000,
        gasPrice: await web3.eth.getGasPrice(),
        nonce: nonce++,
        data: token.methods.transfer(recipient, amountToSend).encodeABI()
      };
      const signed = await web3.eth.accounts.signTransaction(tx, '0x' + privateKey);
      await web3.eth.sendSignedTransaction(signed.rawTransaction);
      success++;
    } catch (err) {
      console.error('Failed to send to', recipient, err.message);
      failed++;
    }
  }

  Swal.fire('Transaction Completed', `Success: ${success}, Failed: ${failed}`, failed ? 'warning' : 'success');
});
</script>

</body>
</html>